require 'test_helper'

class MainControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
